package solid;

public class FabricStall extends Stall{
    FabricStall(String name, String category, int visited, int ticket, int duration) {
        super(name, category, visited, ticket, duration);
    }


    @Override
    public int profitFromStall() {
        return this.visited*this.ticket*30;
    }

}
