package solid;

public interface StallMerits {
    public void printMeritsOfTheStall();
}
