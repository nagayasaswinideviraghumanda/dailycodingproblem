package solid;

public interface StallDemerits {
    public void demeritsOfTheStall();
}
