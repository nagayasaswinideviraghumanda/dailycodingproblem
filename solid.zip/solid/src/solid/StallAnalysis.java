package solid;

public class StallAnalysis implements StallMerits {
    @Override
    public void printMeritsOfTheStall() {
        System.out.println("Merits");
    }

}
