package solid;

public interface Novel {
}
