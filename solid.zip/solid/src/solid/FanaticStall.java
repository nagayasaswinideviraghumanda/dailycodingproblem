package solid;

public class FanaticStall extends Stall {

    FanaticStall(String name, String category, int visited, int ticket, int duration) {
        super(name, category, visited, ticket, duration);
    }
    public void printSpecial() {
        System.out.println("Free of cost on articles for the organized fanatic event winners ");
    }

    @Override
    public int profitFromStall() {
        return 1;
    }
}
