package solid;

public class FoodStall extends Stall{
    FoodStall(String name, String category, int visited, int ticket, int duration) {
        super(name, category, visited, ticket, duration);
    }

    @Override
    public int profitFromStall() {
        return this.visited*this.ticket*20;
    }
}
