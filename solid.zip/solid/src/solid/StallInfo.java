package solid;

public class StallInfo {
    public void showStallDetails(Stall s) {
        System.out.println(s.name+" is organized for a duration of "+s.duration+" hours");
    }
}
