package solid;

public interface Fiction {
}
