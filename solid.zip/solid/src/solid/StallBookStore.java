package solid;

public class StallBookStore extends Stall implements Novel,Fiction {
    Novel novel;
    Fiction fiction;
    StallBookStore(String name, String category, int visited, int ticket, int duration,Novel novel,Fiction fiction) {
        super(name, category, visited, ticket, duration);
        this.novel=novel;
        this.fiction=fiction;
    }

}
