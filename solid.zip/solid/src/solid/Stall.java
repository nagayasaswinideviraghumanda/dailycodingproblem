package solid;

public class Stall   {
    String name;
    String category;
    int visited;
    int ticket;
    int duration;
    Stall(String name,String category,int visited,int ticket,int duration){
        this.name=name;
        this.category=category;
        this.visited=visited;
        this.ticket=ticket;
        this.duration=duration;
    }

    public int profitFromStall() {
             return visited*ticket;
        }

}
